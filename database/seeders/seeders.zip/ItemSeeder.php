<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Item;

class ItemSeeder extends Seeder
{
    public function run(): void
    {
        $items = [
            [
                'id' => 'PC-001',
                'name' => 'High-Performance Workstation',
                'category' => 'Desktop',
                'desc' => 'Standard development workstation.',
                'status' => 'Active',
                'qty' => 50,
                'price' => 1200.00,
                'warehouse' => 'Main Warehouse',
                'zone' => 'Zone A',
                'minLimit' => 10,
                'maxLimit' => 100,
                'auto_reorder' => true,
                'reorder_qty' => 20,
            ],
            [
                'id' => 'PART-001',
                'name' => 'RTX 4090 GPU',
                'category' => 'Component',
                'desc' => 'High-end graphics card.',
                'status' => 'Active',
                'qty' => 15,
                'price' => 1600.00,
                'warehouse' => 'East Hub',
                'zone' => 'Zone C',
                'minLimit' => 5,
                'maxLimit' => 30,
                'auto_reorder' => false,
                'reorder_qty' => null,
            ],
            [
                'id' => 'NET-001',
                'name' => 'Cisco Switch 48-Port',
                'category' => 'Networking',
                'desc' => 'Enterprise core switch.',
                'status' => 'Active',
                'qty' => 8,
                'price' => 850.00,
                'warehouse' => 'Main Warehouse',
                'zone' => 'Zone B',
                'minLimit' => 2,
                'maxLimit' => 15,
                'auto_reorder' => true,
                'reorder_qty' => 5,
            ]
        ];

        foreach ($items as $item) {
            Item::create($item);
        }
    }
}