<?php $__env->startSection('content'); ?>
<div class="min-h-screen flex flex-col md:flex-row w-full bg-gray-50 text-gray-800 font-sans">
    <!-- Meta Configuration Setup for Interfacing APIs inside layouts -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Left Navigation Sidebar -->
    <aside class="w-full md:w-64 bg-[#1E3A8A] text-white flex flex-col justify-between md:sticky md:top-0 md:h-screen shadow-xl z-20 shrink-0">
        <div class="flex flex-col">
            <div class="p-6 border-b border-white/10">
                <h1 class="text-lg font-bold tracking-wide text-white">ERP Inventory</h1>
                <p class="text-[10px] text-blue-200 uppercase tracking-widest mt-0.5">Management System</p>
            </div>

            <?php
                $currentRoute = request()->route()->getName();
                $activeClass = 'font-bold text-white bg-white/10 border-l-4 border-[#10B981] rounded-r-lg';
                $inactiveClass = 'font-semibold text-blue-100 border-l-4 border-transparent hover:text-white hover:bg-white/10 rounded-lg';
            ?>

            <nav class="p-4 flex flex-col gap-1.5 overflow-y-auto flex-1">

                <!-- Dashboard -->
                <a href="<?php echo e(route('inventory.dashboard', ['tab' => 'dashboard'])); ?>"
                class="nav-item px-4 py-2.5 text-xs transition-all <?php echo e($currentRoute === 'inventory.dashboard' ? $activeClass : $inactiveClass); ?>">
                    Dashboard
                </a>

                <!-- Inventory Items -->
                <a href="<?php echo e(route('inventory.index')); ?>"
                class="nav-item px-4 py-2.5 text-xs transition-all <?php echo e($currentRoute === 'inventory.index' ? $activeClass : $inactiveClass); ?>">
                    Inventory Items
                </a>

                <!-- Stock Movements -->
                <a href="<?php echo e(route('stock-movements.index')); ?>"
                class="nav-item px-4 py-2.5 text-xs transition-all <?php echo e($currentRoute === 'stock-movements.index' ? $activeClass : $inactiveClass); ?>">
                    Stock Movements
                </a>

                <!-- Warehouse Layout -->
                <a href="<?php echo e(route('warehouse.layout')); ?>"
                class="nav-item px-4 py-2.5 text-xs transition-all <?php echo e($currentRoute === 'warehouse.layout' ? $activeClass : $inactiveClass); ?>">
                    Warehouse Layout
                </a>

                <!-- Alerts & Reorders (now its own page) -->
                <a href="<?php echo e(route('inventory.alerts')); ?>" id="nav-alerts"
                class="nav-item px-4 py-2.5 text-xs transition-all flex items-center justify-between <?php echo e($currentRoute === 'inventory.alerts' ? $activeClass : $inactiveClass); ?>">
                    <span>Alerts & Reorders</span>
                    <span id="nav-alerts-badge" class="hidden ml-2 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full leading-none"></span>
                </a>

                <!-- Returns & QC -->
                <a href="<?php echo e(route('inventory.dashboard', ['tab' => 'returns'])); ?>"
                class="nav-item px-4 py-2.5 text-xs transition-all <?php echo e($currentRoute === 'inventory.dashboard' ? $inactiveClass : $inactiveClass); ?>">
                    Returns & QC
                </a>

                <!-- Product Bundling -->
                <a href="<?php echo e(route('inventory.dashboard', ['tab' => 'bundling'])); ?>"
                class="nav-item px-4 py-2.5 text-xs transition-all <?php echo e($inactiveClass); ?>">
                    Product Bundling
                </a>

            </nav>
        </div>

        <div class="p-4 border-t border-white/10 bg-black/10 flex items-center justify-between text-sm font-semibold">
            <div class="flex items-center gap-2 text-xs text-blue-100">
                <span class="w-2 h-2 rounded-full bg-[#10B981]"></span>
                <select id="currentUserSession" class="bg-transparent font-bold text-white focus:outline-none cursor-pointer">
                    <option value="Admin 1" class="text-gray-800">Admin 1</option>
                    <option value="Admin 2" class="text-gray-800">Admin 2</option>
                    <option value="Admin 3" class="text-gray-800">Admin 3</option>
                    <option value="Admin 4" class="text-gray-800">Admin 4</option>
                </select>
            </div>
            <button onclick="alert('Logging out...')" class="hover:text-red-300 text-white/80 transition-colors flex items-center gap-1 py-1 px-2 rounded hover:bg-white/5 text-xs">
                Logout
            </button>
        </div>
    </aside>

    <!-- Main Content -->
    <div class="flex-1 h-screen overflow-y-auto relative w-full bg-gray-50">
        <?php echo $__env->make('inventory.alerts-reorders', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>

<script>
    // This page's own scoped state fetch — it no longer shares appState with
    // the dashboard tab or any other page. If stock changes elsewhere, this
    // page won't know until it's reloaded or synced (see syncAlertsState below).
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    const headers = { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken };
    let appState = <?php echo json_encode($initialData, 15, 512) ?>;

    // Alerts & Reorders doesn't call refreshAllUI() (that function belonged to
    // the old shared SPA and touched Dashboard/Returns/Bundling DOM nodes that
    // no longer exist on this page). Each mutation handler in alerts-reorders.blade.php
    // still tries to call it in a try/catch, so nothing breaks — it just silently
    // no-ops here.

    document.addEventListener('DOMContentLoaded', function () {
        // The shared partial ships with class="hidden" because it was built to be
        // one of several toggled tabs. On its own page it should always be visible.
        const view = document.getElementById('view-alerts');
        if (view) view.classList.remove('hidden');
        alertsRenderAll();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.warehouse', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\inventory-dashboardreturnsqcbundling\resources\views/inventory/alerts-page.blade.php ENDPATH**/ ?>