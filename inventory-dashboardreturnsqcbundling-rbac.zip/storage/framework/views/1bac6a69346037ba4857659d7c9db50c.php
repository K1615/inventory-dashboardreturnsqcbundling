<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(config('app.name', 'ERP Inventory Management System')); ?></title>

    <!-- This will pull in the CSRF token, Tailwind CDN, Chart.js, and specific styles from submodule.blade.php -->
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body class="antialiased bg-gray-50">
    
    <!-- This will pull in the entire dashboard layout (sidebar, main content, modals) -->
    <?php echo $__env->yieldContent('content'); ?>

</body>
</html><?php /**PATH D:\laragon\www\inventory-dashboardreturnsqcbundling\resources\views/layouts/app.blade.php ENDPATH**/ ?>