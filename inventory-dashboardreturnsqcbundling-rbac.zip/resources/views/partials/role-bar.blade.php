{{-- Shared "logged in as" indicator + logout, and JS globals for role-based UI gating.
     Include near the top of the sidebar/header in each main page. --}}
<div class="flex items-center justify-between gap-2 px-3 py-2 mb-2 rounded-lg bg-gray-100 border border-gray-200 text-xs">
    <div class="truncate">
        <span class="text-gray-500">Logged in as</span>
        <span class="font-bold text-gray-900">{{ \App\Support\Roles::currentName() }}</span>
        <span class="ml-1 px-1.5 py-0.5 rounded bg-navyBlue text-white font-bold uppercase text-[10px]">{{ \App\Support\Roles::label() }}</span>
    </div>
    <form method="POST" action="{{ route('logout') }}">
        @csrf
        <button type="submit" class="text-gray-500 hover:text-red-600 font-semibold whitespace-nowrap">Log out</button>
    </form>
</div>

<script>
    // Global role context for front-end button gating.
    // The server enforces every permission independently — this is only
    // used to disable/gray-out buttons the current role can't use.
    window.APP_ROLE = @json(\App\Support\Roles::current());
    window.APP_PERMISSIONS = @json(config('roles.permissions'));

    window.canDo = function (permission) {
        if (!window.APP_ROLE) return false;
        const allowed = window.APP_PERMISSIONS[permission];
        // Unlisted permission => open to any logged-in role.
        if (!allowed) return true;
        return allowed.includes(window.APP_ROLE);
    };

    // Takes a <button ...>Label</button> HTML string built via a JS template
    // literal and, if the current role can't do `permission`, injects a
    // disabled attribute + tooltip + grayed-out class into it.
    // The server-side "permission" middleware is what actually blocks the
    // request either way — this only affects what the button looks like.
    window.gatedBtn = function (html, permission) {
        if (window.canDo(permission)) return html;
        return html
            .replace('<button ', '<button disabled title="Requires Manager access" ')
            .replace(/class="/, 'class="opacity-40 cursor-not-allowed pointer-events-none ');
    };

    // Applies disabled styling + a tooltip to an element when the current
    // role lacks `permission`. Call after you build/insert the element.
    window.applyPermissionGate = function (el, permission) {
        if (!el) return;
        if (!window.canDo(permission)) {
            el.disabled = true;
            el.classList.add('opacity-40', 'cursor-not-allowed');
            el.classList.remove('hover:bg-emeraldGreen/90', 'hover:bg-red-600', 'hover:bg-blue-800', 'hover:bg-blue-700');
            el.title = 'Requires Manager access';
            el.onclick = null;
        }
    };
</script>
